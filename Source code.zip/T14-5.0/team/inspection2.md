# Team *T14* - Inspection *2*
 
Inspection | Details
----- | -----
Subject | *App.js fetch methods and render method and constructor *
Meeting | *Nov 8, 10:30, Alesworth*
Checklist | *Naming conventions, consistency, dead code*

### Roles
Name | Role | Preparation Time
---- | ---- | ----
Josh Mau | Dev | 50
Steve Porsche | Dev | 50
Tanishk Bajaj | Dev | 50
Michael Lynn | Dev | 45

### Log
file:line | defect | h/m/l | github# | who
--- | --- |:---:|:---:| ---
App.js:5, 117 | svg is dead code | l | 194 | open
App.js:51, 82 | poor naming conventions for fetch methods | l | 195 | open
 
