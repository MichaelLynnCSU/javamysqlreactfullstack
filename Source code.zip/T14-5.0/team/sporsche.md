Stephen Porsche

ISTP

1. Text and Email both work about equally well. Best time is generally after 11am.
2. I expect for our team to finish all of the assignments/deliverables on time.
3. My personal goals are to stay in communication with the team throughout the process to
ensure that progress is being made so that I, and the team do not fall behind
4. Personal life tends to get in the way, there will be weeks where other things will be more
important (or at least seem more important)
5. I believe that striving for an A is important, but if everyone does an equal share, and the
grade ends up being a B, I won’t be that broken up
6. If one person ends up doing a majority of the work to get an A, that isn’t ok. The work
should be fairly evenly split. If someone ends up doing just a bit more, then that is ok.
7. Not having seen the assignments I’m not sure, but I could guess at least 3-6 hours per
week per person
8. Not entirely sure, the group should have a meeting soon after the assignments are
posted and decide as a group who should do what
9. Have a team meeting to discuss the issue, if the person is a no-show/it happens again,
set up a meeting with the professor to discuss the issue
10. Have another group member look at the work/test it. If it works in a bunch of test
cases/then it works. If it doesn’t, it wasn’t good enough.
11. As long as the work is all done, submitted and tested on time, I won’t have a problem
with how the work gets done
12. That would probably be a good idea, but I can remain flexible
13. We should probably meet at least once a week, perhaps more as the deadline
approaches
14. Depends on the decision, small ones probably no, big ones, probably yes
15. For better or for worse, probably go with the majority
16. Take it upon myself to try and take more responsibility
17. Try to delegate tasks as best as I can
