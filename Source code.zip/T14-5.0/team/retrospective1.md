# T14 Retrospective for Sprint 1

Area | What we did well | What we need to work on | What we will change
:--- | :------- | :--------- | :---------------------
**Teamwork** | Communication, worked through issues well together for having 3 members | Examine where we're at and our performance more often | Schedule weekly meetings to touch base, help each other out and compare code
**Process** | Determined roles well, divided work | Starting sooner so we're not pushing to the last minute, more test cases | Set a schedule as to what to complete each week
**Tools** | Learned new programs/tools well (intelliJ/Maven/npm) | Become more familiar with intelliJ/git/Maven | Become more dependant on the new tools

