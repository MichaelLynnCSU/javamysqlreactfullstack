Tanishk Bajaj

ENFP

1. Text. After 10 am and before 1 am. 
2. My team would do all assignments on time and will produce the best possible result. 
3. I will try to be as responsible and punctual as possible. Also would try to indulge in group discussions regularly.  
4. Maybe “Time management” would be an obstacle. 
5. I will try to make people who want “b” to aim for an “A” and would try to make them more comfortable about the assignments.  
6. No, everyone should contribute equally. 
7. Approximately 5-6 hours a week. 
8. By looking at every one’s skill set and how comfortable are they with the given task. 
9. First step would be to remind him/her of their respected duties and if still did not take interest then report it to professor. 
10. Would try to figure out which opinion is more legit and makes work more easier or would ask help from TA. 
11. I would definitely try to adjust myself as much as possible but if still did not work, I would tell group members to agree on some stuff I find problem with. 
12. Yes, it would definitely be more helpful to complete the assignment.  
13. It would actually depend upon the project, but at least 2 days a week. 
14. Yes 
15. Would definitely listen to him/her prospective but would do whatever the group decides as whole.  
16. I would ask him/her to take all the responsibilities then. 
17. I would not have problem in it but would ask the group members to lower down my work load if I feel it’s too much.   
