# Team *T14* - Inspection *1*
 
Inspection | Details
----- | -----
Subject | *edu.csu2017fa314.T14.Model Lines 1 - 249*
Meeting | *11/1 @ 10:00 in Alesworth*
Checklist | *http://users.csc.calpoly.edu/~jdalbey/301/Forms/CodeReviewChecklistJava.pdf*

### Roles
Name | Role | Preparation Time
---- | ---- | ----
Josh | Developer | 50 minutes
Tanishk | Developer | 50 minutes
Steve | Developer | 55 minutes
Michael | Developer | 50 minutes

### Log
file:line | defect | h/m/l | github# | who
--- | --- |:---:|:---:| ---
9,10,11,13 | Uninitialized Variables | l | #164 | jjmau14
41-43 | Unused code | l | #165 | jjmau14
59 | final var radius | l | #166 | sporsche
 
