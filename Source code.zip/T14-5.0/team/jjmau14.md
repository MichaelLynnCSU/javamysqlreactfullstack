Josh Mau

INFJ

1. Text is fastest but I check email several times as well each day.
2. Complete all assignments at or preferably before due date. Create something useful.
3. I would like to become more dependent on others to finish their code and I’ll finish mine.
4. All have busy schedules and likely won’t be working on the code the same times. Or differences
of opinion.
5. I think a B is acceptable but would obviously prefer an A so I would like to shoot for that, but I
wouldn’t feel let down or angry over a B.
6. Yes, within reason (40-30-30 or 35-35-30 percentages I’d say is acceptable). I’m sure some parts
will require more work for certain group members different weeks.
7. Probably 8 – 10. Hard to know until we decide what we want to do.
8. Whoever feels they could do that part the best or if someone wants to try that part.
9. We should try to do planning and 30% of the project the first week, 50% of the project the
second week and 20% and polishing on the third week. If we stick to this we’ll be fine, otherwise
let us know what’s up ahead of time and we can probably help out.
10. Find a middle ground, should shoot for high quality, good comments and should be individually
tested before putting projects together.
11. Everyone has different styles, if we can find a few middle ground on things like comments and
naming conventions the rest isn’t a big deal. I’m okay with spaces or tabs, I prefer tabs but I can
set tab = 2 or 4 spaces no big deal.
12. I’d like to meet in person at least once a week to check progress and possibly skype if we need
more meetings since we can share screens/etc.
13. ^
14. Decisions that impact the project as a whole, yes. Individual parts I don’t care as long as it works.
15. See if we can bridge the gap a bit more otherwise its 3 vs 1.
16. If things are going well I don’t care. If we start losing points id like to revisit how we make
decision.
17. Ask others to take on a bit of my parts. 
