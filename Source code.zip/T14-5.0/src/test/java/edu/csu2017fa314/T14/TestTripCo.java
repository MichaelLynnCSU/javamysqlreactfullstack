package edu.csu2017fa314.T14;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TestTripCo {

}
