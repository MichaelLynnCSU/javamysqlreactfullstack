package edu.csu2017fa314.T14.Util;

import java.util.ArrayList;

public class DatabaseColumns {

    public static ArrayList<String> COLUMN_NAMES;

}
