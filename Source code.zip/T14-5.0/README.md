# T14 - Team XIV
* Josh Mau, jjmau14, jjmau14 
* Stephen Porsche, sporsche, sporsche23
* Tanishk Bajaj, tanishk, tanishkbajaj
* Michael Lynn, mikelynn, MichaelLynnCSU, mike

| Sprint # | Model - Data | Model - Itinerary | View - Server | View - Client |
|----------|--------------|-------------------|---------------|---------------|
|    1     |   Josh Mau   |   Steve Porsche   | Tanishk Bajaj |      ALL      |
|    2     | Tanishk Bajaj|    Josh Mau       | Steve Porsche |      ALL      |
|    3     | Steve Porsche|   Tanishk Bajaj   | Josh Mau      |      ALL      |
|    4     |     ALL      |       ALL         |      ALL      |      ALL      |
|    5     |              |                   |               |               |

## Server connection information
Server will be hosted at `bugatti.cs.colostate.edu` port **4009** for the web front end and port **6003** for the server backend
